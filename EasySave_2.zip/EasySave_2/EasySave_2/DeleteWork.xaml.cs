﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections;

namespace EasySave_2
{
    /// <summary>
    /// Logique d'interaction pour DeleteWork.xaml
    /// </summary>
    public partial class DeleteWork : Window
    {
 
        public DeleteWork()
        {   
            InitializeComponent();
            Model.WorkList.Clear();
			Model.ReadDataList();
			lbSaves.ItemsSource = Model.WorkList;
        }

        private void DeleteBtn_Click(object sender, RoutedEventArgs e)
        {
            if(lbSaves.SelectedItem != null)
            {
                Model.WorkList.Remove(lbSaves.SelectedItem as Work);
                Model.SaveDataFile();
                this.Close();
                App.Current.MainWindow.Show();
            }
        }

        private void GetBackBtn_Click(object sender,RoutedEventArgs e)
        {
            this.Close();
            App.Current.MainWindow.Show();
        }

        //private void btnChangeUser_Click(object sender, RoutedEventArgs e)
        //{
        //	if (lbUsers.SelectedItem != null)
        //		(lbUsers.SelectedItem as Work).Name = "Random Name";
        //}

    }

}
