﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EasySave_2
{
    /// <summary>
    /// Logique d'interaction pour SaveAllWorks.xaml
    /// </summary>
    public partial class SaveAllWorks : Window
    {
        public SaveAllWorks()
        {
            InitializeComponent();
            Model.WorkList.Clear();
            Model.ReadDataList();
            lbSaves.ItemsSource = Model.WorkList;
        }

        private void SaveAllWorkBtn_Click(object sender, RoutedEventArgs e)
        {
            for(int i = 0; i < lbSaves.Items.Count; i++)
            {
                lbSaves.SelectedIndex = i;
                if (lbSaves.SelectedItem != null)
                {
                    SaveAction.CreateDirectories(lbSaves);
                    SaveAction.CopyFiles(lbSaves);
                    MessageBox.Show("Save Completed");
                }
            }
        }

        private void GetBackBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            App.Current.MainWindow.Show();
        }
    }
}
