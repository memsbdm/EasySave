﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace EasySave_2
{
    public class SaveAction
    {
        public static long FileTransferTime { get; set; }
        public static string FileSrcPath { get; set; }
        public static string FileDestPath { get; set; }
        public static long FileSize { get; set; }
        public static string Key { get; set; }
        public static bool Encrypt { get; set; } = false;

        public static void CreateDirectories(ListBox list)
        {
            Work work = (Work)list.SelectedItem;
            foreach (var dirPath in Directory.GetDirectories(work.SrcPath, "*", SearchOption.AllDirectories))
            {
                Directory.CreateDirectory(dirPath.Replace(work.SrcPath, work.DestPath));
            }
        }

        public static int GetDifferentFilesNb(ListBox list)
        {
            Work work = (Work)list.SelectedItem;
            int nbFiles = 0;
            foreach (var filePath in Directory.GetFiles(work.SrcPath, "*.*", SearchOption.AllDirectories))
            {
                if (!File.Exists(filePath.Replace(work.SrcPath, work.DestPath)))
                {
                    nbFiles++;
                }
                else
                {
                    if (File.GetLastWriteTime(filePath) != File.GetLastWriteTime(filePath.Replace(work.SrcPath, work.DestPath)))
                    {
                        nbFiles++;
                    }
                }
            }
            return nbFiles;

        }

        public static void GetProgression(ListBox list)
        {
            Work work = (Work)list.SelectedItem;
            work.Progression = (double)(100 - (((double)(work.NbFilesLeftToDo) / (work.TotalFilesToCopy)) * 100));
        }

        public static void GetNbLeftToDo(ListBox list)
        {
            Work work = (Work)list.SelectedItem;
            if (work.Type == WorkType.complete)
            {
                work.NbFilesLeftToDo = work.TotalFilesToCopy;
            }
            else if (work.Type == WorkType.differential)
            {
                work.NbFilesLeftToDo = GetDifferentFilesNb(list);
            }

        }

        public static void CopyFiles(ListBox list)
        {
            
            Work work = (Work)list.SelectedItem;
            GetNbLeftToDo(list);

            foreach (var filePath in Directory.GetFiles(work.SrcPath, "*.*", SearchOption.AllDirectories))
            {
                var targetPath = filePath.Replace(work.SrcPath, work.DestPath);
                if (work.NbFilesLeftToDo == 0)
                    continue;
                else
                {
                    var watch = new Stopwatch();
                    watch.Start();
                    if (Encrypt)
                    {
                        if (work.Type == WorkType.complete)
                        {
                            File.Copy(filePath, targetPath, true);
                            EncryptProcess(targetPath);
                            work.NbFilesLeftToDo--;
                        }
                        else
                        {
                            if (!File.Exists(targetPath))
                            {
                                File.Copy(filePath, targetPath, true);
                                EncryptProcess(targetPath);
                                work.NbFilesLeftToDo--;
                            }
                            else
                            {
                                if (File.GetLastWriteTime(filePath) != File.GetLastWriteTime(targetPath))
                                {
                                    File.Copy(filePath, targetPath, true);
                                    EncryptProcess(targetPath);
                                    work.NbFilesLeftToDo--;
                                }

                            }
                        }
                        work.WorkState = WorkState.active;
                        watch.Stop();
                        GetProgression(list);
                        var fi = new FileInfo(filePath);
                        FileTransferTime = watch.ElapsedMilliseconds;
                        FileSrcPath = Path.GetFullPath(filePath);
                        FileDestPath = Path.GetFullPath(filePath).Replace(work.SrcPath, work.DestPath);
                        FileSize = fi.Length;
                        if (work.NbFilesLeftToDo != 0)
                        {
                            work.WorkState = WorkState.active;
                        }
                        else
                        {
                            work.WorkState = WorkState.ended;
                        }
                        LogClass.WriteLogger(list);
                        LogClass.WriteStateLogger(list);
                    }
                    else
                    {
                        if (work.Type == WorkType.complete)
                        {
                            File.Copy(filePath, targetPath, true);
                            work.NbFilesLeftToDo--;
                        }
                        else
                        {
                            if (!File.Exists(targetPath))
                            {
                                File.Copy(filePath, targetPath, true);
                                work.NbFilesLeftToDo--;
                            }
                            else
                            {
                                if (File.GetLastWriteTime(filePath) != File.GetLastWriteTime(targetPath))
                                {
                                    File.Copy(filePath, targetPath, true);
                                    work.NbFilesLeftToDo--;
                                }

                            }
                        }
                        work.WorkState = WorkState.active;
                        watch.Stop();
                        GetProgression(list);
                        var fi = new FileInfo(filePath);
                        FileTransferTime = watch.ElapsedMilliseconds;
                        FileSrcPath = Path.GetFullPath(filePath);
                        FileDestPath = Path.GetFullPath(filePath).Replace(work.SrcPath, work.DestPath);
                        FileSize = fi.Length;
                        if (work.NbFilesLeftToDo != 0)
                        {
                            work.WorkState = WorkState.active;
                        }
                        else
                        {
                            work.WorkState = WorkState.ended;
                        }
                        LogClass.WriteLogger(list);
                        LogClass.WriteStateLogger(list);
                    }


                }
            }
                
            Console.WriteLine("Sauvegarde termin�e.");
        }

        public static int FilesToCopy(DirectoryInfo _directory_srcPath)
        {
            int TotaFilesNb = 0;
            foreach (FileInfo ffinfo in _directory_srcPath.GetFiles())
            {
                TotaFilesNb++;
            }
            foreach (DirectoryInfo subDir in _directory_srcPath.GetDirectories())
            {
                TotaFilesNb += FilesToCopy(subDir);
            }

            return TotaFilesNb;
        }

        public static long DirectorySize(DirectoryInfo _directory_srcPath)
        {
            long TotalDirSize = 0;
            foreach (FileInfo finfo in _directory_srcPath.GetFiles())
            {
                TotalDirSize += finfo.Length;
            }
            foreach (DirectoryInfo subDir in _directory_srcPath.GetDirectories())
            {
                TotalDirSize += DirectorySize(subDir);
            }

            return TotalDirSize;
        }

        public static void EncryptProcess(string destPath)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = @"C:\Users\cimbo\source\repos\CryptoSoft\CryptoSoft\bin\Debug\net6.0\CryptoSoft.exe";
            startInfo.Arguments = $"{destPath} {Key}";
            Process.Start(startInfo);
        }



    }
}
