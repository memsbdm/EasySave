﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Xml;

namespace EasySave_2
{
    public class LogClass
    {

        public static void WriteLog(ListBox list)
        {
            Work work = (Work)list.SelectedItem;
            var easySaveLogJsonPath = Path.Combine(Directory.GetCurrentDirectory(), "EasySaveLog.json");
            var logPath = easySaveLogJsonPath.Replace(@"bin\Debug\net6.0-windows", "Logs");
            using (StreamWriter sw = new StreamWriter(logPath, true))
            {

                sw.WriteLine("{");
                sw.WriteLine($"\"Name\": \"{work.Name}\", ");
                sw.WriteLine($"\"FileSource\": \"{SaveAction.FileSrcPath}\", ");
                sw.WriteLine($"\"FileTarget\": \"{SaveAction.FileDestPath}\", ");
                sw.WriteLine($"\"FileSize\": {SaveAction.FileSize}, ");
                sw.WriteLine($"\"FileTransferTime\": {SaveAction.FileTransferTime} ");
                sw.WriteLine($"\"time\": {GetTimestamp(DateTime.Now)} ");
                sw.WriteLine("}");
            }
        }

        public static void WriteLogXML(ListBox list)
        {
            Work work = (Work)list.SelectedItem;
            var easySaveLogXmlPath = Path.Combine(Directory.GetCurrentDirectory(), "EasySaveLog.xml");
            var logPath = easySaveLogXmlPath.Replace(@"bin\Debug\net6.0-windows", "Logs");
            var settings = new XmlWriterSettings
            {
                OmitXmlDeclaration = true,
                Indent = true
            };

            using (var sw = new StreamWriter(logPath, true))
            {
                using (XmlWriter writer = XmlWriter.Create(sw, settings))
                {
                    writer.WriteStartElement("Save");
                    writer.WriteAttributeString("Name", work.Name);
                    writer.WriteElementString("FileSource", SaveAction.FileSrcPath);
                    writer.WriteElementString("FileTarget", SaveAction.FileDestPath);
                    writer.WriteElementString("FileSize", XmlConvert.ToString(SaveAction.FileSize));
                    writer.WriteElementString("FileTransferTime", XmlConvert.ToString(SaveAction.FileTransferTime));
                    writer.WriteElementString("time", GetTimestamp(DateTime.Now));
                    writer.WriteEndElement();
                }
                sw.WriteLine("\n");
            }

        }

        public static void WriteStateLog(ListBox list)
        {
            Work work = (Work)list.SelectedItem;
            var easySaveStateLogJsonPath = Path.Combine(Directory.GetCurrentDirectory(), "EasySaveStateLog.json");
            var logPath = easySaveStateLogJsonPath.Replace(@"bin\Debug\net6.0-windows", "Logs");
            using (StreamWriter sw = new StreamWriter(logPath, true))
            {

                sw.WriteLine("{");
                sw.WriteLine($"\"Name\": \"{work.Name}\", ");
                sw.WriteLine($"\"SourceDir\": \"{work.SrcPath}\", ");
                sw.WriteLine($"\"TargetDir\": \"{work.DestPath}\", ");
                sw.WriteLine($"\"State\": \"{work.WorkState}\", ");
                sw.WriteLine($"\"TotalFilesToCopy\": {work.TotalFilesToCopy}, ");
                sw.WriteLine($"\"TotalFilesSize\": {work.TotalDirSize}, ");
                sw.WriteLine($"\"NbFilesLeftToDo\": {work.NbFilesLeftToDo} ");
                sw.WriteLine($"\"Progression\": {work.Progression} ");
                sw.WriteLine("}");
            }
        }

        public static void WriteStateLogXML(ListBox list)
        {
            Work work = (Work)list.SelectedItem;
            var easySaveStateLogXmlPath = Path.Combine(Directory.GetCurrentDirectory(), "EasySaveStateLog.xml");
            var logPath = easySaveStateLogXmlPath.Replace(@"bin\Debug\net6.0-windows", "Logs");
            var settings = new XmlWriterSettings
            {
                OmitXmlDeclaration = true,
                Indent = true
            };
            using (var sw = new StreamWriter(logPath, true))
            {

                using (XmlWriter writer = XmlWriter.Create(sw, settings))
                {
                    writer.WriteStartElement("Save");
                    writer.WriteAttributeString("Name", work.Name);
                    writer.WriteElementString("SourceDir", work.SrcPath);
                    writer.WriteElementString("TargetDir", work.DestPath);
                    writer.WriteElementString("State", work.WorkState.ToString());
                    writer.WriteElementString("TotalFilesToCopy", XmlConvert.ToString(work.TotalFilesToCopy));
                    writer.WriteElementString("TotalFilesSize", XmlConvert.ToString(work.TotalDirSize));
                    writer.WriteElementString("NbFilesLeftToDo", XmlConvert.ToString(work.NbFilesLeftToDo));
                    writer.WriteElementString("Progression", XmlConvert.ToString(work.Progression));
                    writer.WriteEndElement();
                }
                sw.WriteLine("\n");
            }

        }

        public static void WriteLogger(ListBox list)
        {
            WriteLog(list);
            WriteLogXML(list);
        }

        public static void WriteStateLogger(ListBox list)
        {
            WriteStateLog(list);
            WriteStateLogXML(list);
        }

        public static String GetTimestamp(DateTime value)
        {
            return value.ToString("dd/MM/yyyy HH:mm:ss");
        }



    }
}
