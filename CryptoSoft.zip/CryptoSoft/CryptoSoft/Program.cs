﻿using System;


namespace CryptoSoft
{
	class Program
	{
		public static void Main(string[] args)
		{
            try
            {
				if (args.Length == 0)
				{
					Console.WriteLine("Enter directory path :");
					var path = Console.ReadLine();
					Console.WriteLine("Enter key :");
					var key = Console.ReadLine();
					XOR.EncryptFile(path, key);

				}
				else
				{
					XOR.EncryptFile(args[0], args[1]);
				}
			}
			catch(Exception e)
            {
				Environment.Exit(0);
            }

		}
	}
}