﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CryptoSoft
{
    public class XOR
    {
        public static void XorEncryption(string destPath, string key)
        {
            byte[] fileText = File.ReadAllBytes(destPath);
            var encrypted = new byte[fileText.Length];

            for (int i = 0; i < fileText.Length; i++)
            {
                encrypted[i] = (byte)(fileText[i] ^ key[i % key.Length]);
            }
            File.WriteAllBytes(destPath, encrypted);
        }

        public static void EncryptFile(string path, string key)
        {
            XorEncryption(path, key);
        }
    }
}
